# Fluxo Inteligente · Capim Dourado Shopping

Plataforma de **Spatial Analytics** para shopping centers: transforma eventos de
passagem capturados pelas câmeras em **mapa de calor** (hotspots/coldspots por
horário), **análise de jornada** (trajetos A → B, caminhos até um destino,
tráfego cruzado entre setores), **dashboard operacional** (pessoas presentes,
entradas/saídas e alertas de ocupação), **visão computacional por câmera** e
**estacionamento inteligente** (cada vaga verde = livre, vermelha = ocupada). MVP montado sobre a planta mix do Capim Dourado
(nov/2026) e o visual do painel GeoPulse.

```
fluxo-inteligente/
├── index.py                 entrada do app na Vercel (preset Python): expõe `app` de backend/app
├── vercel.json              cron diário de simulação
├── requirements.txt         dependências instaladas pela Vercel
├── backend/                 FastAPI + SQL (Python)
│   ├── app/
│   │   ├── main.py          rotas REST, auth, CORS, serve o frontend
│   │   ├── config.py        variáveis de ambiente
│   │   ├── database.py      SQLite (local) ou PostgreSQL (DATABASE_URL), esquema e seed
│   │   ├── queries.py       carrega as consultas nomeadas de sql/queries.sql
│   │   ├── security.py      senha PBKDF2 + token HMAC (stdlib)
│   │   ├── schemas.py       contratos Pydantic
│   │   └── services/
│   │       ├── ingest.py     regra de negócio da ingestão (infere origem, agrega por hora)
│   │       ├── analytics.py  heatmap, métricas, jornadas
│   │       ├── simulator.py  simula visitantes e vagas (substitui a Monuv no MVP)
│   │       └── parking.py    estado das vagas, histórico e eventos de vaga
│   ├── sql/
│   │   ├── schema.sql            esquema usado pelo MVP (SQLite)
│   │   ├── schema.postgres.sql   mesmo modelo para PostgreSQL (Neon/Vercel)
│   │   ├── seed.sql              pavimentos, setores, 52 zonas e câmeras do Capim Dourado
│   │   ├── queries.sql           todas as consultas de relatório (fonte única do SQL)
│   │   ├── parking.schema*.sql   tabelas do estacionamento (SQLite / PostgreSQL)
│   │   └── parking.seed.sql      4 setores e 752 vagas (Subsolos 1 e 2 conforme a planta)
│   └── tests/test_integration.py testes de integração ponta a ponta (pytest)
├── vision/                  visão computacional na borda (YOLO + ByteTrack -> eventos anônimos)
│   ├── worker.py · tracking.py · config.exemplo.json · tests/
├── public/                  frontend: HTML + CSS + JS puro
│   ├── script.js            login, mapa de calor, jornadas, métricas, modo demonstração
│   ├── dashboard.js · vision.js · parking.js   telas Dashboard, Câmeras · Visão, Estacionamento
│   ├── index.html · styles.css · script.js
│   ├── data/mall.js         zonas para o modo demonstração (gerado do seed.sql)
│   └── assets/              plantas recortadas do PDF + exemplos de visão computacional
└── scripts/
    ├── preparar_banco.py    cria tabelas/admin e simula dias no banco (rode antes do 1º acesso)
    ├── gerar_seed_estacionamento.py   gera parking.seed.sql
    ├── exportar_plantas.py  PDF da planta -> PNG dos pavimentos
    └── gerar_mall_js.py     seed.sql -> public/data/mall.js
```

## Executar

```bash
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

- Painel: <http://localhost:8000/> — login padrão `admin@capimdourado.com.br` / `fluxo2026`
  (troque com `FLUXO_ADMIN_EMAIL` / `FLUXO_ADMIN_PASSWORD` antes do primeiro start).
- Documentação interativa da API: <http://localhost:8000/docs>
- No primeiro start o banco `backend/fluxo.db` é criado e o dia de hoje é
  simulado com 3.000 visitantes (`FLUXO_AUTO_SIMULATE=0` desliga).

**Sem backend** (ex.: Vercel, ou abrindo o arquivo direto): abra
`public/index.html` e clique em **Entrar em modo demonstração** (ou use
`?demo=1`). O mesmo modelo de simulação roda no navegador. Para apontar o
frontend para uma API em outro endereço use `?api=https://minha-api`.

### Testes (prática sorteada: testes de integração)

```bash
cd backend && pytest
```

Para rodar a mesma suíte também no PostgreSQL (o banco de teste é apagado a cada teste):

```bash
TEST_DATABASE_URL=postgresql://usuario:senha@localhost/fluxo_test pytest
```

`test_fluxo_completo_vestuario_para_praca_de_alimentacao` reproduz o cenário da
documentação: dispara `POST /api/events` com um visitante saindo do vestuário
(Stilo) e chegando à Praça de Alimentação às 12h30, confere as linhas gravadas
em `movement_events` e `zone_hourly_stats`, e valida em seguida os `GET` que o
frontend consome (heatmap, trajetos, matriz de setores, caminhos, jornada e
linha do tempo). Os outros testes cobrem lote com fuso horário, validações e
autenticação, o simulador e a sincronia entre `seed.sql` e `public/data/mall.js`.

## Deploy na Vercel (frontend + API + PostgreSQL Neon)

A Vercel detecta o projeto como **Python**, carrega o FastAPI de `index.py`
(rotas `/api/*`) e serve `public/` (o painel) pela CDN. O SQLite não serve em função serverless (o disco é apagado),
então em produção o banco é **PostgreSQL**: o Postgres do Marketplace da Vercel
é o **Neon**, que injeta `DATABASE_URL` no projeto automaticamente.

1. **Suba o código no GitHub** (repositório privado de preferência).
2. **Importe na Vercel:** *Add New… → Project* → escolha o repositório.
   Framework Preset: **Python** (detectado sozinho). Root Directory: a raiz do
   projeto (a pasta que contém `index.py`). Não precisa de build command.
   Também funciona arrastando a pasta descompactada em *vercel.com/new*.
3. **Crie o banco:** no projeto, aba **Storage → Create Database → Neon (Postgres)**
   → conecte ao projeto (Production e Preview). Isso cria `DATABASE_URL`.
4. **Variáveis de ambiente** (*Settings → Environment Variables*):

   | Variável | Valor |
   |---|---|
   | `FLUXO_SECRET_KEY` | texto aleatório longo (assina os tokens de login): `python -c "import secrets;print(secrets.token_urlsafe(48))"` |
   | `FLUXO_ADMIN_EMAIL` | e-mail do primeiro administrador |
   | `FLUXO_ADMIN_PASSWORD` | senha forte do administrador |
   | `FLUXO_INGEST_KEY` | chave que as câmeras/Monuv usam no header `X-API-Key` |
   | `CRON_SECRET` | texto aleatório; a Vercel o envia ao chamar o cron diário |
   | `FLUXO_AUTO_SIMULATE` | `0` (em serverless os dados de demonstração vêm do cron/script) |

   Com PostgreSQL a API **se recusa a iniciar** se `FLUXO_SECRET_KEY`,
   `FLUXO_ADMIN_PASSWORD` ou `FLUXO_INGEST_KEY` estiverem vazias ou com o valor
   padrão de desenvolvimento.
5. **Prepare o banco uma vez** a partir do seu computador, com a connection
   string do Neon (Storage → Neon → *Connection string*):

   ```bash
   pip install -r backend/requirements.txt
   DATABASE_URL="postgresql://...neon.tech/neondb?sslmode=require" \
   FLUXO_SECRET_KEY="o-mesmo-do-passo-4" FLUXO_INGEST_KEY="o-mesmo-do-passo-4" \
   FLUXO_ADMIN_EMAIL="voce@capimdourado.com.br" FLUXO_ADMIN_PASSWORD="a-mesma-do-passo-4" \
   python scripts/preparar_banco.py --dias 7
   ```

   Cria as tabelas, as 52 zonas, o administrador e 7 dias simulados (segundos:
   a carga usa `COPY`). Se pular este passo, a API cria as tabelas sozinha no
   primeiro acesso, mas sem dados de movimento.

   **Antes de conectar o Neon** o deploy já funciona para demonstração: sem
   `DATABASE_URL`, a API usa um SQLite temporário em `/tmp` e simula o dia na
   primeira requisição (login padrão `admin@capimdourado.com.br` / `fluxo2026`).
   Esses dados somem quando a função reinicia — não use assim em produção.
6. **Deploy** (*Deployments → Redeploy*, ou qualquer push no GitHub). Acesse
   `https://seu-projeto.vercel.app` e entre com o administrador; o painel usa
   a API na mesma origem. `https://seu-projeto.vercel.app/api/health` deve
   responder `"database": "postgres"`.

O cron do `vercel.json` (`0 9 * * *` = 06:00 em Palmas) chama
`/api/cron/simulate` e gera o dia corrente, para o painel sempre ter dados de
"hoje" enquanto a integração com as câmeras não existe. Quando a Monuv estiver
ligada, remova o bloco `crons` e envie os eventos reais para `POST /api/events`.

Outro Postgres (Supabase, Railway, RDS...) funciona igual: basta `DATABASE_URL`.

## Telas novas

**Dashboard** — o painel "Fluxo Capim Dourado" na paleta do sistema: pessoas no
shopping agora, entradas e saídas (15 min / última hora / hoje), área mais
movimentada, alertas por área com limite configurável (salvo no navegador),
fluxo por horário, comparação entre áreas e tabela. Presença = última detecção
de cada visitante nos últimos 150 min, sem contar quem já saiu por um acesso.
Capacidade simultânea de cada área = passagens/h confortáveis × permanência
média do setor (estimativa; ajuste em `analytics.DWELL_MID_MIN`).

**Câmeras · Visão computacional** — uma câmera por zona (52). Mostra os números
reais do backend (pessoas na zona, entradas/saídas da última hora, última
detecção) e uma **cena ilustrativa gerada por computador** do ambiente
(corredor, praça de alimentação ou entrada, com as lojas vizinhas da planta)
com a mesma sobreposição que o worker calcula: caixa e id por pessoa, trilhas,
linha de contagem, ROI e rosto anonimizado. Exemplo:
`public/assets/exemplo-visao-computacional.png`. A cena não é imagem real.

**Estacionamento** — inspirado nos sistemas de orientação por luz (vaga verde =
livre, vermelha = ocupada): letreiro por setor com vagas livres, recomendação
do setor com mais vagas, mapa de todas as 752 vagas (com PNE, idoso 60+,
neurodiverso e gestante), ocupação por hora e câmera ilustrativa que decide
vaga a vaga (`public/assets/exemplo-estacionamento.png`).
Subsolo 1 (140) e Subsolo 2 (216) seguem a planta mix; Estacionamento Norte e
Bolsão Sul **não têm total na planta** e estão marcados como estimativa —
ajuste em `scripts/gerar_seed_estacionamento.py`.

## Visão computacional nas câmeras (`vision/`)

Roda numa máquina na rede das câmeras (borda), não na Vercel:

```bash
pip install -r vision/requirements.txt
python vision/worker.py --config vision/config.exemplo.json --camera MNV-P2-MESAS-CENTRO \
  --api https://seu-projeto.vercel.app --api-key "$FLUXO_INGEST_KEY"
```

- **Pessoas:** YOLOv8 detecta, ByteTrack mantém o id entre quadros; quem fica
  3 quadros dentro da ROI vira um evento `POST /api/events/batch` para a zona.
- **Estacionamento** (`"mode": "estacionamento"`): polígono por vaga; a vaga
  muda de estado quando um veículo cobre ≥ 45% dela por 5 quadros seguidos
  (evita piscar com sombras e pessoas) → `POST /api/parking/events`.
- **LGPD:** nenhum quadro é gravado ou enviado; o id que sai da câmera é um
  hash que muda todo dia (`FLUXO_TRACK_SALT`); `--show` borra a cabeça antes
  de exibir. Ligar a mesma pessoa entre câmeras (jornada A → B) exige o id
  anônimo de reidentificação da plataforma de visão (ex.: Monuv).
- `--dry-run` imprime os eventos sem enviar; teste com um vídeo usando `--source arquivo.mp4`.
- **Vídeo gravado:** `vision/processar_video.py` roda o mesmo pipeline num
  arquivo e gera `public/assets/videos/demo.mp4` (cabeças pixelizadas, sem
  áudio) + `demo.json`/`demo.js` (caixas, ids e contagens por quadro). A tela
  "Câmeras · Visão" abre nesse vídeo e desenha a detecção sincronizada.
  Para trocar por uma gravação real do Capim Dourado:

  ```bash
  python vision/processar_video.py gravacao.mp4 public/assets/videos/demo \
    --label "Corredor central · Capim Dourado" --source-note "Câmera MNV-..., 14/11/2026" \
    --roi "0.04,0.26;0.96,0.26;1,1;0,1" --line "0.08,0.66;0.92,0.66"
  ```

  O vídeo de demonstração atual é de **outro shopping** (placas em russo) e só
  ilustra a técnica; confira a licença antes de publicar.
- As regras (linha, ROI, vaga) estão em `vision/tracking.py` e têm testes
  sem GPU: `python -m pytest vision/tests`.

## API

| Método | Rota | Uso |
|---|---|---|
| POST | `/api/auth/login` | Tela 1 · retorna token Bearer |
| GET | `/api/auth/me` | usuário logado |
| POST | `/api/events` | ingestão de 1 passagem (câmera: header `X-API-Key`) |
| POST | `/api/events/batch` | até 5.000 passagens, atômico |
| GET | `/api/heatmap?floor=T&date=&hour=` | Tela 2 · zonas com passagens, ocupação, intensidade e nível |
| GET | `/api/heatmap/timeline?date=` | passagens por hora (barras do rodapé) |
| GET | `/api/metrics/summary?date=&hour=` | visitantes, hotspots, zona mais ocupada, pico |
| GET | `/api/metrics/dwell?date=` | permanência média por zona |
| GET | `/api/journeys/transitions?from_zone=&to_zone=` | Tela 3 · trajetos A → B |
| GET | `/api/journeys/sector-matrix` | tráfego cruzado entre setores |
| GET | `/api/journeys/paths-to/{zona}` | até 3 zonas percorridas antes do destino (ex.: cinema) |
| GET | `/api/journeys/sector/{setor}` | de onde vem / para onde vai quem passa pelo setor |
| GET | `/api/visitors/{track_id}/journey` | jornada completa de um visitante anonimizado |
| GET | `/api/dashboard?at=&period=now\|hour\|today` | dashboard: presentes, entradas/saídas por área, série horária |
| GET | `/api/cameras?at=` | as 52 câmeras: pessoas na zona, entradas/saídas da última hora |
| GET | `/api/parking?at=` | estado de cada vaga (livre/ocupada) e resumo por setor |
| GET | `/api/parking/history?date=` | ocupação de cada setor por hora |
| POST | `/api/parking/events` | mudança de estado de vaga (câmera/sensor, header `X-API-Key`) |
| POST | `/api/simulate` | (admin) gera um dia simulado (visitantes + vagas) |

Exemplo de evento vindo da integração com câmeras:

```bash
curl -X POST localhost:8000/api/events \
  -H "X-API-Key: dev-ingest-key" -H "Content-Type: application/json" \
  -d '{"track_id":"MNV-8842","to_zone":"P2-MESAS-CENTRO","occurred_at":"2026-11-14T12:30:00-03:00","camera_id":"MNV-P2-MESAS-CENTRO","source":"monuv"}'
```

`from_zone` é opcional: se a câmera só informa onde o visitante entrou, o
backend usa a última detecção do mesmo `track_id` (até 4 h) como origem.

## Regras de negócio

- **Ocupação** = passagens no intervalo ÷ (`capacity_hour` × horas). Hotspot
  ≥ 80%, coldspot ≤ 25%. A capacidade de cada zona fica em `seed.sql`.
- **Intensidade do heatmap** combina ocupação (60%) e volume relativo à zona
  mais movimentada do pavimento (40%).
- Horários sempre no fuso do shopping (America/Araguaina, UTC-3); eventos com
  fuso são convertidos na ingestão.
- O simulador usa um modelo gravitacional (atratividade ÷ distância na planta),
  intenções de visita (refeição no Piso 2, sessão de cinema) e troca de piso
  apenas pelas escadas rolantes.

## Planta e zonas

As imagens dos pavimentos saem das páginas 2 (Térreo) e 3 (Piso 2 · Praça de
Alimentação) do PDF `2026_11_CDS_MIX.pdf`. As 52 zonas (32 no térreo, 20 no
piso 2) têm coordenadas em % sobre essas imagens. Para reposicionar ou incluir
uma zona: edite `backend/sql/seed.sql`, rode `python scripts/gerar_mall_js.py`
e apague `backend/fluxo.db` para recriar o banco.

## Próximos passos (roadmap da documentação)

- Trocar o simulador pelo webhook da Monuv (`source = 'monuv'`, `camera_id`).
- Vagas de estacionamento em tempo real e alertas de fluxo anormal para a segurança.
