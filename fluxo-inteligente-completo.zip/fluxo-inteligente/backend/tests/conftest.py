import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import Settings  # noqa: E402
from app.database import connect, drop_all  # noqa: E402
from app.main import create_app  # noqa: E402

ADMIN = {"email": "admin@teste.local", "password": "senha-de-teste"}
INGEST_KEY = "chave-ingestao-teste"
PG_URL = os.getenv("TEST_DATABASE_URL", "")


@pytest.fixture(params=["sqlite", "postgres"])
def db_url(request, tmp_path) -> str:
    """Cada teste roda no SQLite e, se TEST_DATABASE_URL existir, também no PostgreSQL."""
    if request.param == "sqlite":
        return f"sqlite:///{tmp_path / 'fluxo-test.db'}"
    if not PG_URL:
        pytest.skip("defina TEST_DATABASE_URL para testar no PostgreSQL")
    db = connect(PG_URL)
    drop_all(db)  # banco de teste é recriado do zero
    db.close()
    return PG_URL


@pytest.fixture()
def settings(db_url) -> Settings:
    return Settings(
        db_url=db_url,
        secret_key="segredo-de-teste",
        ingest_key=INGEST_KEY,
        token_ttl_hours=1,
        admin_email=ADMIN["email"],
        admin_password=ADMIN["password"],
        auto_simulate=False,
        simulated_visitors=0,
        cors_origins=("*",),
        cron_secret="cron-teste",
    )


@pytest.fixture()
def client(settings):
    with TestClient(create_app(settings)) as c:
        yield c


@pytest.fixture()
def auth(client) -> dict:
    res = client.post("/api/auth/login", json=ADMIN)
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


@pytest.fixture()
def db(settings, auth):  # `auth` garante que o esquema já foi criado
    conn = connect(settings.db_url)
    yield conn
    conn.close()
