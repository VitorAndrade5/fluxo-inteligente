"""Testes de integração ponta a ponta (prática sorteada).

Fluxo validado: POST de um evento de passagem -> regra de negócio e
persistência no banco relacional -> GET nos relatórios que alimentam o
mapa de calor e a análise de trajeto do frontend.
"""
import json
from datetime import datetime
from pathlib import Path

from .conftest import INGEST_KEY

DAY = "2026-11-14"
INGEST = {"X-API-Key": INGEST_KEY}


def test_fluxo_completo_vestuario_para_praca_de_alimentacao(client, auth, db):
    """'Visitante passou do corredor de roupas para a praça de alimentação às 12h30'."""
    # 1. Simulação (input): visitante entra pelo térreo, passa no vestuário e sobe para comer
    trajeto = [
        ("T-ENT-SUL", "12:05:00"),
        ("T-STILO", "12:10:00"),        # loja de vestuário
        ("T-ESC-CENTRAL", "12:24:00"),
        ("P2-ESC", "12:26:00"),
        ("P2-MESAS-CENTRO", "12:30:00"),  # praça de alimentação às 12h30
    ]
    respostas = []
    for zona, hora in trajeto:
        res = client.post("/api/events", headers=INGEST, json={
            "track_id": "VIS-INTEG-001", "to_zone": zona,
            "occurred_at": f"{DAY}T{hora}", "camera_id": f"MNV-{zona}", "source": "monuv",
        })
        assert res.status_code == 201, res.text
        respostas.append(res.json())

    # a origem foi inferida pela detecção anterior do mesmo visitante
    assert respostas[0]["from_zone"] is None
    assert [r["from_zone"] for r in respostas[1:]] == [z for z, _ in trajeto[:-1]]
    assert respostas[-1]["bucket_start"] == f"{DAY}T12:00:00"

    # 2. Persistência: dados íntegros nas tabelas relacionais
    rows = db.execute(
        """SELECT fz.code AS origem, tz.code AS destino, e.occurred_at, e.source, c.external_id
           FROM movement_events e
           JOIN visitors v ON v.id = e.visitor_id
           JOIN zones tz ON tz.id = e.to_zone_id
           LEFT JOIN zones fz ON fz.id = e.from_zone_id
           LEFT JOIN cameras c ON c.id = e.camera_id
           WHERE v.track_id = 'VIS-INTEG-001' ORDER BY e.occurred_at"""
    ).fetchall()
    assert len(rows) == 5
    assert (rows[-1]["origem"], rows[-1]["destino"]) == ("P2-ESC", "P2-MESAS-CENTRO")
    assert str(rows[-1]["occurred_at"]).replace(" ", "T") == f"{DAY}T12:30:00"
    assert all(r["source"] == "monuv" for r in rows)
    assert rows[1]["external_id"] == "MNV-T-STILO"
    stat = db.execute(
        """SELECT h.entries FROM zone_hourly_stats h JOIN zones z ON z.id = h.zone_id
           WHERE z.code = 'P2-MESAS-CENTRO' AND h.bucket_start = ?""", (f"{DAY}T12:00:00",)
    ).fetchone()
    assert stat["entries"] == 1

    # 3. Validação de retorno (output): o que o frontend consome
    heat = client.get("/api/heatmap", headers=auth, params={"floor": "P2", "date": DAY, "hour": 12}).json()
    zonas = {z["code"]: z for z in heat["zones"]}
    assert zonas["P2-MESAS-CENTRO"]["entries"] == 1
    assert zonas["P2-MESAS-CENTRO"]["intensity"] == 1.0
    assert {"x", "y", "radius", "level", "occupancy"} <= zonas["P2-MESAS-CENTRO"].keys()
    assert heat["total_entries"] == 2  # P2-ESC + mesas

    # fora da janela (13h) não aparece
    heat13 = client.get("/api/heatmap", headers=auth, params={"floor": "P2", "date": DAY, "hour": 13}).json()
    assert heat13["total_entries"] == 0

    trans = client.get("/api/journeys/transitions", headers=auth,
                       params={"date": DAY, "from_zone": "P2-ESC"}).json()
    assert trans == [{
        "from_code": "P2-ESC", "from_name": "Escadas rolantes · Piso 2",
        "to_code": "P2-MESAS-CENTRO", "to_name": "Mesas · setor central",
        "from_floor": "P2", "to_floor": "P2", "total": 1,
    }]

    matriz = client.get("/api/journeys/sector-matrix", headers=auth, params={"date": DAY}).json()["matrix"]
    assert matriz["vestuario"]["circulacao"] == 1
    assert matriz["circulacao"]["alimentacao"] == 1

    caminhos = client.get("/api/journeys/paths-to/P2-MESAS-CENTRO", headers=auth, params={"date": DAY}).json()
    assert caminhos["paths"][0]["steps"] == ["T-STILO", "T-ESC-CENTRAL", "P2-ESC", "P2-MESAS-CENTRO"]

    setor = client.get("/api/journeys/sector/vestuario", headers=auth, params={"date": DAY}).json()
    assert setor["origins"][0]["code"] == "T-ENT-SUL"
    assert setor["destinations"][0]["code"] == "T-ESC-CENTRAL"

    jornada = client.get("/api/visitors/VIS-INTEG-001/journey", headers=auth).json()
    assert [s["to_zone"] for s in jornada["steps"]] == [z for z, _ in trajeto]

    timeline = client.get("/api/heatmap/timeline", headers=auth, params={"date": DAY}).json()["hours"]
    assert next(h for h in timeline if h["hour"] == 12)["entries"] == 5


def test_lote_com_fuso_horario_e_resumo(client, auth):
    res = client.post("/api/events/batch", headers=auth, json={"events": [
        # 18:00Z = 15:00 em Palmas (UTC-3); fora de ordem de propósito
        {"track_id": "VIS-2", "to_zone": "t-cinemark", "occurred_at": "2026-11-14T18:00:00Z"},
        {"track_id": "VIS-2", "to_zone": "T-EST-NORTE", "occurred_at": "2026-11-14T14:40:00-03:00"},
    ]})
    assert res.status_code == 201, res.text
    eventos = res.json()["events"]
    assert eventos[1]["occurred_at"] == f"{DAY}T15:00:00"
    assert eventos[1]["from_zone"] == "T-EST-NORTE"

    resumo = client.get("/api/metrics/summary", headers=auth, params={"date": DAY}).json()
    assert resumo["events"] == 2 and resumo["visitors"] == 1
    assert resumo["by_floor"] == {"T": 2, "P2": 0}


def test_regras_de_validacao_e_acesso(client, auth, db):
    base = {"track_id": "VIS-3", "occurred_at": f"{DAY}T10:00:00"}
    assert client.post("/api/events", json={**base, "to_zone": "T-BIG"}).status_code == 401
    assert client.post("/api/events", headers={"X-API-Key": "errada"}, json={**base, "to_zone": "T-BIG"}).status_code == 401
    assert client.post("/api/events", headers=INGEST, json={**base, "to_zone": "NAO-EXISTE"}).status_code == 422
    assert client.post("/api/events", headers=INGEST,
                       json={**base, "to_zone": "T-BIG", "from_zone": "T-BIG"}).status_code == 422
    # lote é atômico: um evento inválido desfaz todos
    res = client.post("/api/events/batch", headers=INGEST, json={"events": [
        {**base, "to_zone": "T-BIG"}, {**base, "to_zone": "ZONA-X", "occurred_at": f"{DAY}T10:05:00"},
    ]})
    assert res.status_code == 422
    assert db.scalar("SELECT COUNT(*) AS n FROM movement_events") == 0

    assert client.get("/api/heatmap").status_code == 401
    assert client.get("/api/heatmap", headers={"Authorization": "Bearer forjado.xyz"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "admin@teste.local", "password": "x"}).status_code == 401
    assert client.get("/api/heatmap", headers=auth, params={"floor": "P9"}).status_code == 404


def test_simulador_gera_dia_coerente(client, auth):
    res = client.post("/api/simulate", headers=auth, json={"date": DAY, "visitors": 300, "seed": 7})
    assert res.status_code == 200, res.text
    gerado = res.json()
    resumo = client.get("/api/metrics/summary", headers=auth, params={"date": DAY}).json()
    assert resumo["visitors"] == 300
    assert resumo["events"] == gerado["events"]
    assert resumo["by_floor"]["P2"] > 0
    horas = {h["hour"]: h["entries"] for h in
             client.get("/api/heatmap/timeline", headers=auth, params={"date": DAY}).json()["hours"]}
    assert horas[13] > horas[10]  # pico de almoço acima da abertura

    # repetir com replace não duplica
    client.post("/api/simulate", headers=auth, json={"date": DAY, "visitors": 300, "seed": 7})
    assert client.get("/api/metrics/summary", headers=auth, params={"date": DAY}).json()["events"] == gerado["events"]


def test_cron_exige_segredo_e_simula_hoje(client):
    assert client.get("/api/cron/simulate").status_code == 401
    assert client.get("/api/cron/simulate", headers={"Authorization": "Bearer errado"}).status_code == 401
    res = client.get("/api/cron/simulate", headers={"Authorization": "Bearer cron-teste"})
    assert res.status_code == 200, res.text
    assert res.json()["visitors"] == 0 or "events" in res.json()


def test_dados_de_reserva_do_frontend_batem_com_o_banco(client, auth):
    """public/data/mall.js (modo demonstração) precisa espelhar as zonas do seed.sql."""
    js = (Path(__file__).resolve().parents[2] / "public" / "data" / "mall.js").read_text(encoding="utf-8")
    payload = json.loads(js[js.index("{"): js.rindex("}") + 1])
    api = client.get("/api/zones", headers=auth).json()
    chave = lambda z: (z["code"], z["floor"], z["sector"], z["x"], z["y"], z["radius"], z["capacity_hour"])
    assert sorted(map(chave, payload["zones"])) == sorted(map(chave, api))


def test_dashboard_presentes_entradas_e_saidas(client, auth):
    """Visitante entra, vai à praça de alimentação e sai: presença e contagens do painel."""
    for zona, hora in [("T-ENT-SUL", "12:00:00"), ("T-ESC-CENTRAL", "12:05:00"), ("P2-ESC", "12:07:00"),
                       ("P2-MCDONALDS", "12:10:00"), ("P2-MESAS-CENTRO", "12:20:00")]:
        assert client.post("/api/events", headers=INGEST,
                           json={"track_id": "VIS-DASH", "to_zone": zona, "occurred_at": f"{DAY}T{hora}"}).status_code == 201

    d = client.get("/api/dashboard", headers=auth, params={"at": f"{DAY}T12:30:00", "period": "hour"}).json()
    areas = {a["id"]: a for a in d["areas"]}
    assert d["totals"] == {"peoplePresent": 1, "entries": 1, "exits": 0}
    assert areas["alimentacao"]["peoplePresent"] == 1
    assert areas["alimentacao"]["entriesInPeriod"] == 1   # entrou no setor uma vez (McDonald's -> mesas é o mesmo setor)
    assert areas["circulacao"]["exitsInPeriod"] == 1
    assert d["isDemo"] is False                            # nenhum evento do simulador
    assert d["series"]["points"][-1] == {"start": f"{DAY}T12:00:00", "entries": 1, "exits": 0, "partial": True}

    # saída do shopping: deixa de contar como presente
    client.post("/api/events", headers=INGEST, json={"track_id": "VIS-DASH", "to_zone": "T-ENT-SUL",
                                                     "occurred_at": f"{DAY}T12:40:00"})
    d = client.get("/api/dashboard", headers=auth, params={"at": f"{DAY}T12:45:00", "period": "today"}).json()
    assert d["totals"] == {"peoplePresent": 0, "entries": 1, "exits": 1}

    cams = {c["zone"]: c for c in client.get("/api/cameras", headers=auth, params={"at": f"{DAY}T12:30:00"}).json()["cameras"]}
    assert len(cams) == 52
    assert cams["P2-MESAS-CENTRO"]["people_in_view"] == 1
    assert cams["P2-MCDONALDS"]["entries_last_hour"] == 1 and cams["P2-MCDONALDS"]["exits_last_hour"] == 1
    assert cams["P2-MESAS-CENTRO"]["last_detection"] == f"{DAY}T12:20:00"

    assert client.get("/api/dashboard", headers=auth, params={"period": "semana"}).status_code == 422


def test_estacionamento_vagas_verde_e_vermelho(client, auth):
    vazio = client.get("/api/parking", headers=auth, params={"at": f"{DAY}T10:00:00"}).json()
    lotes = {l["code"]: l for l in vazio["lots"]}
    assert vazio["totals"] == {"total": 752, "free": 752, "occupied": 0, "occupancy": 0.0}
    # números da planta mix (pág. 1)
    assert lotes["S1"]["total"] == 140 and lotes["S2"]["total"] == 216
    assert lotes["S1"]["by_kind"]["pne"]["total"] == 3 and lotes["S1"]["by_kind"]["idoso"]["total"] == 11
    assert lotes["S2"]["by_kind"]["pne"]["total"] == 5 and lotes["S2"]["by_kind"]["gestante"]["total"] == 4
    assert lotes["S1"]["is_estimate"] is False and lotes["TN"]["is_estimate"] is True

    # câmera do subsolo detecta carro na vaga e depois a saída
    ok = client.post("/api/parking/events", headers=INGEST,
                     json={"space": "s1-a01", "occupied": True, "occurred_at": f"{DAY}T10:05:00"})
    assert ok.status_code == 201 and ok.json()["source"] == "visao"
    client.post("/api/parking/events", headers=INGEST, json={"space": "S1-A01", "occupied": False, "occurred_at": f"{DAY}T11:40:00"})

    meio = client.get("/api/parking", headers=auth, params={"at": f"{DAY}T11:00:00"}).json()
    s1 = next(l for l in meio["lots"] if l["code"] == "S1")
    vaga = next(v for v in s1["spaces"] if v["code"] == "S1-A01")
    assert vaga == {"code": "S1-A01", "row": 0, "col": 0, "kind": "pne", "occupied": True}
    assert s1["occupied"] == 1 and s1["by_kind"]["pne"]["free"] == 2
    depois = client.get("/api/parking", headers=auth, params={"at": f"{DAY}T12:00:00"}).json()
    assert depois["totals"]["occupied"] == 0

    hist = client.get("/api/parking/history", headers=auth, params={"date": DAY}).json()["lots"]["S1"]
    assert next(h for h in hist if h["hour"] == 10)["occupancy"] == round(1 / 140, 3)
    assert next(h for h in hist if h["hour"] == 11)["occupancy"] == 0

    assert client.post("/api/parking/events", headers=INGEST,
                       json={"space": "X9-Z99", "occupied": True, "occurred_at": f"{DAY}T10:00:00"}).status_code == 422
    assert client.post("/api/parking/events",
                       json={"space": "S1-A01", "occupied": True, "occurred_at": f"{DAY}T10:00:00"}).status_code == 401


def test_simulador_tambem_ocupa_estacionamento(client, auth):
    gerado = client.post("/api/simulate", headers=auth, json={"date": DAY, "visitors": 200, "seed": 3}).json()
    assert gerado["parking_events"] > 0
    noite = client.get("/api/parking", headers=auth, params={"at": f"{DAY}T19:30:00"}).json()["totals"]
    manha = client.get("/api/parking", headers=auth, params={"at": f"{DAY}T10:15:00"}).json()["totals"]
    assert noite["occupancy"] > manha["occupancy"]
    assert client.get("/api/parking", headers=auth, params={"at": f"{DAY}T23:59:00"}).json()["totals"]["occupied"] == 0
