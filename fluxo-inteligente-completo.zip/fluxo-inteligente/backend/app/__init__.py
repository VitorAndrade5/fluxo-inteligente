"""Fluxo Inteligente · backend FastAPI."""
