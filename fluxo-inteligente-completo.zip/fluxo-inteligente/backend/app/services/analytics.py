"""Cálculo das zonas de calor, métricas e análise de jornada."""
from datetime import date, datetime, timedelta

from ..config import CLOSE_HOUR, OPEN_HOUR
from ..database import Database
from ..queries import q

HOT_THRESHOLD = 0.8   # >= 80% da capacidade confortável = hotspot
COLD_THRESHOLD = 0.25  # <= 25% = coldspot


def window(day: date, hour: int | None) -> tuple[str, str]:
    """Intervalo semiaberto [início, fim) da hora selecionada ou do dia inteiro."""
    if hour is None:
        start = datetime.combine(day, datetime.min.time())
        end = start + timedelta(days=1)
    else:
        start = datetime.combine(day, datetime.min.time()) + timedelta(hours=hour)
        end = start + timedelta(hours=1)
    return start.isoformat(), end.isoformat()


def classify(occupancy: float) -> str:
    if occupancy >= HOT_THRESHOLD:
        return "hot"
    if occupancy <= COLD_THRESHOLD:
        return "cold"
    return "moderate"


def heatmap(conn: Database, floor: str, day: date, hour: int | None) -> dict:
    start, end = window(day, hour)
    rows = conn.execute(q("heatmap", conn.dialect), {"floor": floor, "start": start, "end": end}).fetchall()
    if not rows:
        raise LookupError(f"pavimento '{floor}' não existe")
    hours = 1 if hour is not None else CLOSE_HOUR - OPEN_HOUR
    peak = max((r["entries"] for r in rows), default=0) or 1
    zones = []
    for r in rows:
        occupancy = r["entries"] / (r["capacity_hour"] * hours)
        zones.append({
            "code": r["code"], "name": r["name"], "store_ref": r["store_ref"], "sector": r["sector"],
            "x": r["x_pct"], "y": r["y_pct"], "radius": r["radius_pct"],
            "capacity_hour": r["capacity_hour"], "entries": r["entries"],
            "occupancy": round(occupancy, 3),
            "intensity": round(r["entries"] / peak, 3),
            "level": classify(occupancy),
        })
    return {
        "floor": floor, "date": day, "hour": hour,
        "total_entries": sum(z["entries"] for z in zones),
        "hotspots": sum(z["level"] == "hot" for z in zones),
        "coldspots": sum(z["level"] == "cold" for z in zones),
        "zones": zones,
    }


def timeline(conn: Database, day: date, floor: str | None) -> list[dict]:
    start, end = window(day, None)
    found = {r["hour"]: r["entries"] for r in conn.execute(q("timeline", conn.dialect), {"start": start, "end": end, "floor": floor})}
    return [{"hour": h, "entries": found.get(h, 0)} for h in range(OPEN_HOUR, CLOSE_HOUR + 1)]


def summary(conn: Database, day: date, hour: int | None) -> dict:
    start, end = window(day, hour)
    row = conn.execute(q("summary", conn.dialect), {"start": start, "end": end}).fetchone()
    t = heatmap(conn, "T", day, hour)
    p2 = heatmap(conn, "P2", day, hour)
    zones = t["zones"] + p2["zones"]
    busiest = max(zones, key=lambda z: z["occupancy"]) if zones else None
    tl = timeline(conn, day, None)
    peak = max(tl, key=lambda x: x["entries"]) if tl else None
    return {
        "date": day, "hour": hour,
        "events": row["events"], "visitors": row["visitors"],
        "hotspots": t["hotspots"] + p2["hotspots"],
        "coldspots": t["coldspots"] + p2["coldspots"],
        "zones_monitored": len(zones),
        "busiest_zone": busiest and {k: busiest[k] for k in ("code", "name", "occupancy", "entries")},
        "peak_hour": peak if peak and peak["entries"] else None,
        "by_floor": {"T": t["total_entries"], "P2": p2["total_entries"]},
    }


def zone_dwell(conn: Database, day: date, floor: str | None) -> dict[str, float]:
    start, end = window(day, None)
    return {r["code"]: r["avg_minutes"] for r in conn.execute(q("zone_dwell", conn.dialect), {"start": start, "end": end, "floor": floor})}


def transitions(conn, day, hour, from_zone=None, to_zone=None, limit=10) -> list[dict]:
    start, end = window(day, hour)
    params = {"start": start, "end": end, "from_zone": from_zone, "to_zone": to_zone, "limit": limit}
    return [dict(r) for r in conn.execute(q("top_transitions", conn.dialect), params)]


def sector_matrix(conn, day, hour) -> dict:
    start, end = window(day, hour)
    sectors = [dict(r) for r in conn.execute("SELECT code, name, color FROM sectors ORDER BY id")]
    codes = [s["code"] for s in sectors]
    matrix = {a: {b: 0 for b in codes} for a in codes}
    for r in conn.execute(q("sector_matrix", conn.dialect), {"start": start, "end": end}):
        matrix[r["from_sector"]][r["to_sector"]] = r["total"]
    return {"sectors": sectors, "matrix": matrix}


def paths_to(conn, zone: str, day: date, limit=5) -> dict:
    target = conn.execute("SELECT code, name FROM zones WHERE code = ?", (zone,)).fetchone()
    if not target:
        raise LookupError(f"zona '{zone}' não existe")
    start, end = window(day, None)
    paths = []
    for r in conn.execute(q("paths_to_zone", conn.dialect), {"start": start, "end": end, "zone": zone, "limit": limit}):
        steps = [s for s in (r["step1"], r["step2"], r["step3"]) if s]
        paths.append({"steps": steps + [zone], "total": r["total"]})
    return {"zone": dict(target), "paths": paths}


def sector_flow(conn, sector: str, day: date, limit=6) -> dict:
    row = conn.execute("SELECT code, name FROM sectors WHERE code = ?", (sector,)).fetchone()
    if not row:
        raise LookupError(f"setor '{sector}' não existe")
    start, end = window(day, None)
    params = {"start": start, "end": end, "sector": sector, "limit": limit}
    return {
        "sector": dict(row),
        "origins": [dict(r) for r in conn.execute(q("sector_origins", conn.dialect), params)],
        "destinations": [dict(r) for r in conn.execute(q("sector_destinations", conn.dialect), params)],
    }


def visitor_journey(conn, track_id: str) -> list[dict]:
    return [dict(r) for r in conn.execute(q("visitor_journey", conn.dialect), {"track_id": track_id})]


def dates_with_data(conn) -> list[dict]:
    return [dict(r) for r in conn.execute(q("dates_with_data", conn.dialect))]


# ---------------------------------------------------------------- dashboard
# permanência média por setor (min), para estimar a capacidade simultânea de cada área:
# pessoas ao mesmo tempo ≈ passagens/h confortáveis × permanência média
DWELL_MID_MIN = {"ancora": 16.5, "vestuario": 10.5, "alimentacao": 27.5, "entretenimento": 45,
                 "servicos": 9, "circulacao": 3, "acesso": 2}
PRESENCE_WINDOW = timedelta(minutes=150)
PERIOD_MINUTES = {"now": 15, "hour": 60}


def presence(conn: Database, at: datetime) -> dict[str, int]:
    params = {"at": at.isoformat(timespec="seconds"), "since": (at - PRESENCE_WINDOW).isoformat(timespec="seconds")}
    return {r["code"]: r["present"] for r in conn.execute(q("presence_by_zone", conn.dialect), params)}


def dashboard(conn: Database, at: datetime, period: str) -> dict:
    """Resumo no formato do painel operacional: presentes agora, entradas/saídas por área e série horária."""
    day_start = datetime.combine(at.date(), datetime.min.time())
    start = day_start if period == "today" else at - timedelta(minutes=PERIOD_MINUTES[period])
    at_s, start_s = at.isoformat(timespec="seconds"), max(start, day_start).isoformat(timespec="seconds")

    zones = conn.execute(
        """SELECT z.code, s.code AS sector, z.capacity_hour FROM zones z JOIN sectors s ON s.id = z.sector_id"""
    ).fetchall()
    sectors = [dict(r) for r in conn.execute("SELECT code, name, color FROM sectors ORDER BY id")]
    present_by_zone = presence(conn, at)
    capacity = {s["code"]: 0.0 for s in sectors}
    present = {s["code"]: 0 for s in sectors}
    for z in zones:
        capacity[z["sector"]] += z["capacity_hour"] * DWELL_MID_MIN[z["sector"]] / 60
        present[z["sector"]] += present_by_zone.get(z["code"], 0)

    entries = {s["code"]: 0 for s in sectors}
    exits = {s["code"]: 0 for s in sectors}
    mall_in = mall_out = 0
    for r in conn.execute(q("dashboard_flows", conn.dialect), {"start": start_s, "end": at_s}):
        mall_in += r["mall_entries"] or 0
        mall_out += r["mall_exits"] or 0
        if r["from_sector"] != r["to_sector"]:
            entries[r["to_sector"]] += r["total"]
            if r["from_sector"]:
                exits[r["from_sector"]] += r["total"]

    series_start = day_start + timedelta(hours=min(OPEN_HOUR, at.hour))
    points = []
    found = {r["bucket"]: r for r in conn.execute(
        q("dashboard_series", conn.dialect), {"start": series_start.isoformat(), "end": at_s})}
    t = series_start
    while t <= at:
        r = found.get(t.strftime("%Y-%m-%dT%H"))
        points.append({"start": t.isoformat(timespec="seconds"), "entries": (r["entries"] if r else 0) or 0,
                       "exits": (r["exits"] if r else 0) or 0, "partial": t + timedelta(hours=1) > at})
        t += timedelta(hours=1)

    mix = conn.execute(q("source_mix", conn.dialect), {"start": day_start.isoformat(), "end": at_s}).fetchone()
    areas = []
    for s in sectors:
        cap = max(1, round(capacity[s["code"]]))
        areas.append({"id": s["code"], "name": s["name"], "color": s["color"], "capacity": cap,
                      "peoplePresent": present[s["code"]], "entriesInPeriod": entries[s["code"]],
                      "exitsInPeriod": exits[s["code"]],
                      "occupancyPercent": round(present[s["code"]] / cap * 100)})
    return {
        "updatedAt": at_s, "isDemo": bool(mix["simulated"]),
        "period": {"key": period, "from": start_s, "to": at_s},
        "totals": {"peoplePresent": sum(present.values()), "entries": mall_in, "exits": mall_out},
        "areas": areas,
        "series": {"bucket": "hour", "points": points},
    }


def cameras(conn: Database, at: datetime) -> list[dict]:
    """Uma câmera por zona: pessoas no quadro agora, entradas/saídas na última hora."""
    window_start = (at - timedelta(hours=1)).isoformat(timespec="seconds")
    activity = {r["camera_id"]: r for r in conn.execute(
        q("camera_activity", conn.dialect), {"start": window_start, "end": at.isoformat(timespec="seconds")})}
    present = presence(conn, at)
    rows = conn.execute(
        """SELECT c.external_id, c.name AS camera_name, c.active, z.code, z.name, f.code AS floor, s.code AS sector,
                  z.capacity_hour
           FROM cameras c JOIN zones z ON z.id = c.zone_id JOIN floors f ON f.id = z.floor_id
           JOIN sectors s ON s.id = z.sector_id ORDER BY f.level, z.code"""
    ).fetchall()
    out = []
    for r in rows:
        a = activity.get(r["external_id"])
        last = a["last_detection"] if a else None
        out.append({
            "camera_id": r["external_id"], "zone": r["code"], "zone_name": r["name"], "floor": r["floor"],
            "sector": r["sector"], "active": bool(r["active"]),
            "people_in_view": present.get(r["code"], 0),
            "entries_last_hour": (a["entries"] if a else 0) or 0,
            "exits_last_hour": (a["exits"] if a else 0) or 0,
            "last_detection": str(last).replace(" ", "T") if last else None,
            "capacity_hour": r["capacity_hour"],
        })
    return out
