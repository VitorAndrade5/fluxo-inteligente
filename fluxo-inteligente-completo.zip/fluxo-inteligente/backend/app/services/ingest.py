"""Ingestão de eventos de passagem: valida, infere a origem e atualiza o agregado do heatmap."""
from datetime import datetime, timedelta

from ..config import MALL_TZ
from ..database import Database
from ..queries import q


class IngestError(ValueError):
    """Evento inválido (zona/câmera desconhecida, origem igual ao destino...)."""


def to_local_iso(moment: datetime) -> str:
    """Normaliza para o horário local do shopping, sem fuso: 'YYYY-MM-DDTHH:MM:SS'."""
    if moment.tzinfo is not None:
        moment = moment.astimezone(MALL_TZ).replace(tzinfo=None)
    return moment.replace(microsecond=0).isoformat()


class ZoneCache:
    def __init__(self, conn: Database):
        rows = conn.execute("SELECT id, code FROM zones").fetchall()
        self.by_code = {r["code"]: r["id"] for r in rows}
        self.by_id = {r["id"]: r["code"] for r in rows}
        cams = conn.execute("SELECT id, external_id FROM cameras").fetchall()
        self.cameras = {r["external_id"]: r["id"] for r in cams}

    def zone_id(self, code: str, field: str) -> int:
        try:
            return self.by_code[code]
        except KeyError:
            raise IngestError(f"{field}: zona '{code}' não existe") from None


def _visitor_id(conn: Database, track_id: str, occurred_at: str) -> int:
    row = conn.execute("SELECT id FROM visitors WHERE track_id = ?", (track_id,)).fetchone()
    if row:
        return row["id"]
    return conn.execute("INSERT INTO visitors (track_id, first_seen) VALUES (?, ?) RETURNING id",
                        (track_id, occurred_at)).fetchone()["id"]


def record_event(
    conn: Database,
    *,
    track_id: str,
    to_zone: str,
    occurred_at: datetime,
    from_zone: str | None = None,
    camera_id: str | None = None,
    source: str = "api",
    cache: ZoneCache | None = None,
) -> dict:
    """Persiste um evento e incrementa zone_hourly_stats. Não faz commit (o chamador decide)."""
    cache = cache or ZoneCache(conn)
    when = to_local_iso(occurred_at)
    to_id = cache.zone_id(to_zone, "to_zone")
    cam_id = None
    if camera_id:
        cam_id = cache.cameras.get(camera_id)
        if cam_id is None:
            raise IngestError(f"camera_id: câmera '{camera_id}' não cadastrada")

    visitor_id = _visitor_id(conn, track_id, when)

    if from_zone:
        from_id = cache.zone_id(from_zone, "from_zone")
    else:
        window_start = (datetime.fromisoformat(when) - timedelta(hours=4)).isoformat()
        last = conn.execute(
            q("last_event_for_visitor", conn.dialect),
            {"visitor_id": visitor_id, "occurred_at": when, "window_start": window_start},
        ).fetchone()
        from_id = last["to_zone_id"] if last else None

    if from_id == to_id:
        if from_zone:
            raise IngestError("from_zone e to_zone não podem ser iguais")
        from_id = None  # mesma câmera detectou de novo: trata como permanência, não trajeto

    event_id = conn.execute(
        """INSERT INTO movement_events (visitor_id, from_zone_id, to_zone_id, camera_id, occurred_at, source)
           VALUES (?, ?, ?, ?, ?, ?) RETURNING id""",
        (visitor_id, from_id, to_id, cam_id, when, source),
    ).fetchone()["id"]
    bucket = when[:13] + ":00:00"
    conn.execute(q("upsert_hourly_stat", conn.dialect), {"zone_id": to_id, "bucket_start": bucket})
    return {
        "id": event_id,
        "track_id": track_id,
        "from_zone": cache.by_id.get(from_id) if from_id else None,
        "to_zone": to_zone,
        "occurred_at": when,
        "bucket_start": bucket,
        "source": source,
    }
