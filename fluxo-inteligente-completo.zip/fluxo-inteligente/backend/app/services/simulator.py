"""Simulador de visitantes (substitui a integração Monuv no MVP).

Modelo: cada visitante entra por um acesso, percorre de 3 a 9 zonas e sai.
A próxima zona é sorteada por um modelo gravitacional — atratividade da zona
dividida pela distância na planta — com reforços por horário (almoço/jantar
puxam para a Praça de Alimentação, noite puxa para o cinema). A troca de piso
só acontece pelas escadas rolantes (zonas com `connects_to`).

O dia é gerado em memória e gravado em lote (COPY no PostgreSQL), para caber
no tempo de uma função serverless mesmo com o banco remoto (Neon).
"""
import math
import random
from datetime import date, datetime, timedelta

from ..config import CLOSE_HOUR, OPEN_HOUR
from ..queries import q
from ..database import Database
from .analytics import window
from .parking import simulate_parking_day

# peso de chegada por hora (10h..21h)
ARRIVALS = {10: 3, 11: 5, 12: 9, 13: 9, 14: 6, 15: 5, 16: 6, 17: 7, 18: 9, 19: 10, 20: 8, 21: 4}
DWELL_MIN = {  # permanência (min, max) por setor
    "ancora": (8, 25), "vestuario": (5, 16), "alimentacao": (15, 40), "entretenimento": (20, 70),
    "servicos": (4, 14), "circulacao": (1, 5), "acesso": (1, 3),
}
SIGMA = 22.0


def _load_zones(conn: Database) -> list[dict]:
    rows = conn.execute(
        """SELECT z.code, f.code AS floor, f.aspect_ratio, s.code AS sector, z.x_pct, z.y_pct,
                  z.attractiveness, z.is_entrance, z.connects_to
           FROM zones z JOIN floors f ON f.id = z.floor_id JOIN sectors s ON s.id = z.sector_id
           ORDER BY z.code"""
    ).fetchall()
    return [dict(r) for r in rows]


def _boost(zone: dict, hour: int) -> float:
    b = 1.0
    meal = hour in (12, 13, 19, 20)
    if zone["sector"] == "alimentacao" and meal:
        b *= 2.2
    if zone["connects_to"] and zone["floor"] == "P2":
        b *= 0.45  # quem subiu tende a ficar na praça antes de descer
    if zone["connects_to"] and zone["floor"] == "T" and meal:
        b *= 2.0  # no térreo, a escada leva à Praça de Alimentação
    if zone["code"] == "T-CINEMARK" and hour >= 17:
        b *= 2.4
    if zone["sector"] == "entretenimento" and hour >= 15:
        b *= 1.3
    if zone["sector"] in ("ancora", "vestuario") and 15 <= hour <= 18:
        b *= 1.3
    return b


def _next_zone(rng: random.Random, here: dict, zones: list[dict], hour: int, visited: set[str],
               came_from: str | None) -> dict:
    candidates, weights = [], []
    for z in zones:
        if z["code"] == here["code"] or z["is_entrance"]:
            continue
        if z["floor"] != here["floor"]:
            continue
        dx = (z["x_pct"] - here["x_pct"]) * z["aspect_ratio"]
        dy = z["y_pct"] - here["y_pct"]
        w = z["attractiveness"] * _boost(z, hour) * math.exp(-math.hypot(dx, dy) / SIGMA)
        if z["code"] in visited:
            w *= 0.25
        candidates.append(z)
        weights.append(w)
    if here["connects_to"] and came_from != here["connects_to"]:  # na escada: tende a trocar de piso
        target = next(z for z in zones if z["code"] == here["connects_to"])
        candidates.append(target)
        weights.append(sum(weights) * 1.5)
    return rng.choices(candidates, weights)[0]


def _pick(rng: random.Random, options: list[dict]) -> dict:
    return rng.choices(options, [z["attractiveness"] for z in options])[0]


def _plan_goals(rng: random.Random, hour: int, zones: list[dict]) -> list[dict]:
    """Intenção da visita: refeição na Praça de Alimentação e/ou sessão de cinema."""
    by_code = {z["code"]: z for z in zones}
    goals: list[dict] = []
    meal_prob = 0.55 if hour in (11, 12, 13, 18, 19, 20) else 0.18
    if rng.random() < meal_prob:
        stores = [z for z in zones if z["floor"] == "P2" and z["sector"] == "alimentacao" and "MESAS" not in z["code"]]
        tables = [z for z in zones if "MESAS" in z["code"]]
        goals += [by_code["T-ESC-CENTRAL"], by_code["P2-ESC"], _pick(rng, stores), _pick(rng, tables)]
    if rng.random() < (0.3 if hour >= 16 else 0.08):
        if goals:  # desce antes de ir ao cinema
            goals += [by_code["P2-ESC"], by_code["T-ESC-CENTRAL"]]
        goals.append(by_code["T-CINEMARK"])
    return goals


def simulate_day(conn: Database, day: date, visitors: int, seed: int | None = None,
                 replace: bool = True) -> dict:
    """Gera e grava um dia de visitas. Não faz commit (o chamador decide)."""
    rng = random.Random(seed if seed is not None else day.toordinal())
    zones = _load_zones(conn)
    by_code = {z["code"]: z for z in zones}
    zone_ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM zones")}
    entrances = [z for z in zones if z["is_entrance"]]
    start, end = window(day, None)
    prefix = f"SIM-{day.isoformat()}-"

    if replace:
        conn.execute(q("delete_day_events", conn.dialect), {"start": start, "end": end})
        conn.execute("DELETE FROM visitors WHERE track_id LIKE :p AND id NOT IN "
                     "(SELECT visitor_id FROM movement_events)", {"p": prefix + "%"})

    close = datetime.combine(day, datetime.min.time()) + timedelta(hours=CLOSE_HOUR, minutes=30)
    hours, hour_weights = zip(*ARRIVALS.items())
    journeys: list[tuple[str, datetime, list[tuple[str | None, str, datetime]]]] = []
    for i in range(visitors):
        track = f"{prefix}{i:05d}"
        hour = rng.choices(hours, hour_weights)[0]
        t = datetime.combine(day, datetime.min.time()) + timedelta(hours=hour, minutes=rng.randint(0, 59),
                                                                   seconds=rng.randint(0, 59))
        here = rng.choices(entrances, [z["attractiveness"] for z in entrances])[0]
        steps: list[tuple[str | None, str, datetime]] = [(None, here["code"], t)]
        first_seen = t
        visited = {here["code"]}
        came_from = None
        goals = _plan_goals(rng, hour, zones)
        goal_at = rng.randint(0, 2)  # passos livres antes de seguir a intenção
        for step in range(rng.randint(3, 8) + len(goals)):
            lo, hi = DWELL_MIN[here["sector"]]
            if here["code"] == "T-CINEMARK":
                lo, hi = 95, 150
            t += timedelta(minutes=rng.uniform(lo, hi))
            if t >= close:
                break
            if goals and step >= goal_at and goals[0]["code"] != here["code"]:
                nxt = goals.pop(0)
            else:
                if goals and goals[0]["code"] == here["code"]:
                    goals.pop(0)
                nxt = _next_zone(rng, here, zones, t.hour, visited, came_from)
            steps.append((here["code"], nxt["code"], t))
            came_from, here = here["code"], nxt
            visited.add(here["code"])
        # saída: desce pela escada se estiver no Piso 2 e vai ao acesso mais próximo
        if here["floor"] == "P2" and t < close:
            for code in ("P2-ESC", "T-ESC-CENTRAL"):
                if here["code"] == code:
                    continue
                t += timedelta(minutes=rng.uniform(1, 4))
                steps.append((here["code"], code, t))
                here = by_code[code]
        if t < close and not here["is_entrance"]:
            exit_zone = min(entrances, key=lambda z: math.hypot(z["x_pct"] - here["x_pct"], z["y_pct"] - here["y_pct"]))
            t += timedelta(minutes=rng.uniform(1, 5))
            steps.append((here["code"], exit_zone["code"], t))
        journeys.append((track, first_seen, steps))

    # grava em lote: visitantes -> ids -> eventos -> agregado horário do dia
    existing = {r["track_id"] for r in conn.execute(
        "SELECT track_id FROM visitors WHERE track_id LIKE :p", {"p": prefix + "%"})}
    conn.bulk_insert("visitors", ("track_id", "first_seen"),
                     ((track, first.isoformat()) for track, first, _ in journeys if track not in existing))
    visitor_ids = {r["track_id"]: r["id"] for r in conn.execute(
        "SELECT id, track_id FROM visitors WHERE track_id LIKE :p", {"p": prefix + "%"})}
    rows = [
        (visitor_ids[track], zone_ids[f] if f else None, zone_ids[to], when.isoformat(timespec="seconds"), "simulator")
        for track, _, steps in journeys for f, to, when in steps
    ]
    conn.bulk_insert("movement_events", ("visitor_id", "from_zone_id", "to_zone_id", "occurred_at", "source"), rows)
    conn.execute(q("delete_day_stats", conn.dialect), {"start": start, "end": end})
    conn.execute(q("rebuild_day_stats", conn.dialect), {"start": start, "end": end})
    parking_events = simulate_parking_day(conn, day, seed, replace)
    return {"date": day.isoformat(), "visitors": visitors, "events": len(rows), "parking_events": parking_events}
