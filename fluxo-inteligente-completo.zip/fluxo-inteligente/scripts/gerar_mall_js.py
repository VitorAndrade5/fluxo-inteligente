"""Gera public/data/mall.js a partir de backend/sql/schema.sql + seed.sql.

O arquivo é usado pelo painel no modo demonstração (sem API). Rode sempre que
alterar o seed:  python scripts/gerar_mall_js.py
O teste test_dados_de_reserva_do_frontend_batem_com_o_banco falha se esquecer.
"""
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SQL = ROOT / "backend" / "sql"

conn = sqlite3.connect(":memory:")
conn.row_factory = sqlite3.Row
conn.executescript((SQL / "schema.sql").read_text(encoding="utf-8"))
conn.executescript((SQL / "seed.sql").read_text(encoding="utf-8"))
conn.executescript((SQL / "parking.schema.sql").read_text(encoding="utf-8"))
conn.executescript((SQL / "parking.seed.sql").read_text(encoding="utf-8"))

data = {
    "floors": [dict(r) for r in conn.execute("SELECT code, name, level, plan_image, aspect_ratio FROM floors ORDER BY level")],
    "sectors": [dict(r) for r in conn.execute("SELECT code, name, color FROM sectors ORDER BY id")],
    "zones": [dict(r) for r in conn.execute(
        """SELECT z.code, f.code AS floor, s.code AS sector, z.name, z.store_ref, z.x_pct AS x, z.y_pct AS y,
                  z.radius_pct AS radius, z.capacity_hour, z.attractiveness, z.is_entrance, z.connects_to,
                  c.external_id AS camera_id
           FROM zones z JOIN floors f ON f.id = z.floor_id JOIN sectors s ON s.id = z.sector_id
           LEFT JOIN cameras c ON c.zone_id = z.id ORDER BY f.level, z.code""")],
    "parking": [
        {**dict(lot), "specials": [r["kind"] for r in conn.execute(
            "SELECT kind FROM parking_spaces WHERE lot_id = ? AND kind <> 'comum' ORDER BY id", (lot["id"],))]}
        for lot in conn.execute(
            "SELECT id, code, name, level_label, total, rows_count, cols_count, is_estimate, preference FROM parking_lots ORDER BY id")
    ],
}
out = ROOT / "public" / "data" / "mall.js"
out.write_text(
    "// Gerado por scripts/gerar_mall_js.py a partir de backend/sql/seed.sql — não edite à mão.\n"
    "window.MALL_DATA = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n",
    encoding="utf-8",
)
print(f"{out.relative_to(ROOT)}: {len(data['zones'])} zonas")
