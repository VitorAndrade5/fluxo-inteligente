"""Exporta os pavimentos da planta (PDF) do Capim Dourado como PNG para o frontend.

Uso:
    python scripts/exportar_plantas.py caminho/para/2026_11_CDS_MIX.pdf

Requer `pdftoppm` (poppler-utils) e Pillow. As coordenadas das zonas
(backend/sql/seed.sql e public/data/mall.js) são percentuais sobre estes
recortes; se o recorte mudar, as zonas precisam ser reposicionadas.
"""
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image

DPI = 130
BASE_DPI = 60  # recortes abaixo foram medidos a 60 dpi
# página do PDF -> (arquivo de saída, caixa de recorte a 60 dpi)
PAGES = {
    2: ("piso-terreo.png", (430, 160, 1520, 1000)),
    3: ("piso-2.png", (40, 40, 1870, 1250)),
}


def main(pdf: str) -> None:
    out_dir = Path(__file__).resolve().parent.parent / "public" / "assets"
    out_dir.mkdir(parents=True, exist_ok=True)
    scale = DPI / BASE_DPI
    with tempfile.TemporaryDirectory() as tmp:
        for page, (name, box) in PAGES.items():
            prefix = Path(tmp) / f"p{page}"
            subprocess.run(
                ["pdftoppm", "-r", str(DPI), "-png", "-f", str(page), "-l", str(page), pdf, str(prefix)],
                check=True,
            )
            rendered = next(Path(tmp).glob(f"p{page}*.png"))
            img = Image.open(rendered).convert("L")
            crop = img.crop(tuple(round(v * scale) for v in box))
            crop.save(out_dir / name, optimize=True)
            print(f"{name}: {crop.size[0]}x{crop.size[1]}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
