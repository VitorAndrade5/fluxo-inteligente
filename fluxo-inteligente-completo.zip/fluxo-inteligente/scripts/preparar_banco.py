"""Cria as tabelas, o usuário admin e simula dias de movimento no banco.

Uso (PostgreSQL do Neon/Vercel ou SQLite local):
    DATABASE_URL="postgresql://..." \\
    FLUXO_ADMIN_EMAIL="voce@capimdourado.com.br" FLUXO_ADMIN_PASSWORD="senha-forte" \\
    python scripts/preparar_banco.py --dias 7 --visitantes 3000

Rode uma vez antes do primeiro acesso ao painel. Depois, o Vercel Cron
(/api/cron/simulate) gera o dia corrente automaticamente.
"""
import argparse
import sys
import time
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.config import load_settings  # noqa: E402
from app.database import connect, init_db  # noqa: E402
from app.main import today  # noqa: E402
from app.services.simulator import simulate_day  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dias", type=int, default=7, help="quantos dias simular, terminando hoje (0 = só cria tabelas)")
    parser.add_argument("--visitantes", type=int, default=3000, help="visitantes simulados por dia")
    args = parser.parse_args()

    settings = load_settings()
    destino = settings.db_url.split("@")[-1] if "@" in settings.db_url else settings.db_url
    print(f"Banco: {destino}")
    init_db(settings)
    print("Tabelas, zonas e usuário admin prontos.")

    db = connect(settings.db_url)
    try:
        for offset in range(args.dias - 1, -1, -1):
            dia = today() - timedelta(days=offset)
            t0 = time.perf_counter()
            res = simulate_day(db, dia, args.visitantes)
            db.commit()
            print(f"  {dia}: {res['visitors']} visitantes, {res['events']} eventos ({time.perf_counter() - t0:.1f}s)")
    finally:
        db.close()


if __name__ == "__main__":
    main()
